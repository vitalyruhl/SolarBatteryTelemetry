#pragma once

#include "../ConfigManagerConfig.h"

#if CM_ENABLE_WIFI

#include <WiFi.h>
#include <functional>
#include <mutex>
#include <atomic>
#include <esp_err.h>
#include "ConnectivitySocket.h"

// WiFi connection states
enum WiFiManagerState {
  WIFI_STATE_DISCONNECTED,
  WIFI_STATE_CONNECTING,
  WIFI_STATE_CONNECTED,
  WIFI_STATE_AP_MODE,
  WIFI_STATE_RECONNECTING
};

// Callback function types
typedef std::function<void()> WiFiConnectedCallback;
typedef std::function<void()> WiFiDisconnectedCallback;
typedef std::function<void()> WiFiAPModeCallback;

// A failed driver read is unknown (-1), never inferred from the requested mode.
struct WiFiPowerSaveDiagnostics {
  bool requested = CM_WIFI_POWER_SAVE_DEFAULT != 0;
  bool bleCoexistenceRequired = false;
  int effectiveMode = -1;
  esp_err_t readError = ESP_ERR_INVALID_STATE;
  bool applyAttempted = false;
  bool applySucceeded = false;
  esp_err_t applyError = ESP_ERR_INVALID_STATE;
};

class ConfigManagerWiFi {
private:
  // State management
  WiFiManagerState currentState;
  bool autoRebootEnabled;
  bool initialized;

  // Timing variables
  unsigned long lastGoodConnectionMillis;
  unsigned long connectionMonitoringStartedMillis;
  unsigned long lastReconnectAttempt;
  unsigned long reconnectInterval;
  unsigned long autoRebootTimeoutMs;

  // Connection parameters
  String ssid;
  String password;
  IPAddress staticIP;
  IPAddress gateway;
  IPAddress subnet;
  IPAddress dns1;
  IPAddress dns2;
  bool useDHCP;

  // Smart WiFi Roaming
  bool smartRoamingEnabled;
  int roamingThreshold;          // dBm threshold for roaming trigger
  unsigned long roamingCooldown; // Minimum time between roaming attempts (ms)
  int roamingImprovement;        // Minimum signal improvement required (dBm)
  unsigned long lastRoamingScanMillis;
  unsigned long lastRoamingAttempt;

  // MAC Address Filtering and Priority
  bool macFilterEnabled;   // If true, only connect to specific MAC
  bool macPriorityEnabled; // If true, prefer specific MAC but allow fallback
  String filterMac;        // MAC address for filtering/priority
  String priorityMac;      // MAC address for priority (same as filterMac for simplicity)

  // Callback functions
  WiFiConnectedCallback onConnectedCallback;
  WiFiDisconnectedCallback onDisconnectedCallback;
  WiFiAPModeCallback onAPModeCallback;

  // Connection attempt strategy
  // 0 = normal connect, 1 = stack reset, 2+ = periodic retries (no immediate restart; restart is gated by auto-reboot timeout)
  uint8_t connectAttempts;

  // Diagnostics / throttled logs
  unsigned long lastNoSsidScanMillis;
  unsigned long noSsidScanStartMillis;
  bool transientStatusActive;
  int transientStatusCode;
  unsigned long transientStatusStartedMillis;
  unsigned long transientStatusLastLogMillis;

  // Deferred roaming reconnect (non-blocking replacement for fixed delay).
  bool roamingReconnectPending;
  unsigned long roamingReconnectAtMs;
  String roamingTargetBSSID;

  // Non-blocking WiFi stack reset state machine.
  bool stackResetInProgress;
  bool connectAfterStackReset;
  uint8_t stackResetStep;
  unsigned long stackResetStepAtMs;

  cm::detail::ConnectivityCheck connectivityCheck_;
  cm::detail::ConnectivitySocket connectivitySocket_;
  void updateConnectivity_(uint32_t now, bool stationHealthy, bool suspended);

  mutable std::mutex powerSaveMutex_;
  WiFiPowerSaveDiagnostics powerSaveDiagnostics_;
  std::atomic<bool> bleCoexistenceReady_{false};
  uint32_t bleCoexistenceAttemptMs_ = 0; // Application-loop owned, rollover-safe retry clock.
  void applyPowerSave_();

  // Private methods
  void transitionToState(WiFiManagerState newState);
  void handleReconnection();
  void checkAutoReboot();
  void log(const char* format, ...) const;
  void applyStaticConfig();
  void checkSmartRoaming(); // Smart roaming check method
  String findBestBSSID();   // Find best BSSID considering MAC filter/priority
  void attemptConnect();    // Apply phased connection strategy
  bool isOtaActive_() const;
  void beginWiFiConnection_();
  void startStackReset_();
  bool advanceStackReset_();
  void processPendingRoamingReconnect_();
  void logNoSsidAvailScan_();

public:
  // Constructor
  ConfigManagerWiFi();

  // Initialization
  void begin(unsigned long reconnectIntervalMs = 10000, unsigned long autoRebootTimeoutMin = 0);
  void setCallbacks(WiFiConnectedCallback onConnected, WiFiDisconnectedCallback onDisconnected, WiFiAPModeCallback onAPMode = nullptr);

  // Connection management - NON-BLOCKING
  void startConnection(const String& ssid, const String& password);
  void startConnection(const IPAddress& staticIP, const IPAddress& gateway, const IPAddress& subnet, const String& ssid, const String& password, const IPAddress& dns1 = IPAddress(), const IPAddress& dns2 = IPAddress());
  void startAccessPoint(const String& apSSID, const String& apPassword = "");

  // Main update function (call in loop) - NON-BLOCKING
  void update();

  // State queries
  WiFiManagerState getState() const;
  bool isConnected() const;
  bool isInAPMode() const;
  bool isConnecting() const;
  unsigned long getLastConnectionTime() const;
  unsigned long getTimeSinceLastConnection() const;

  // Call the setter only from the loop owner; ConfigManager queues cross-task changes.
  // This changes runtime state only and does not write NVS.
  void setPowerSave(bool enabled);
  // Loop-owner only. The CM BLE controller has no shutdown path; retain until reboot.
  void requireBleCoexistence();
  void retryBleCoexistence();
  bool isBleCoexistenceReady() const {
    return bleCoexistenceReady_.load();
  }
  WiFiPowerSaveDiagnostics getPowerSaveDiagnostics() const;

  // Control functions
  void enableAutoReboot(bool enable);
  void setAutoRebootTimeout(unsigned long timeoutMinutes);
  void setReconnectInterval(unsigned long intervalMs);
  // Call from the loop owner; configuration callbacks must hand off changes to that owner.
  bool setConnectivityCheckTarget(const String& target);
  // ArduinoOTA starts synchronously in the loop; update() cannot observe that transfer's active flag.
  void pauseConnectivityForSynchronousOta();
  void forceReconnect();
  void reconnect();
  void disconnect();
  void reset();

  // Status information
  String getStatusString() const;
  String getWiFiStatusString(int status) const;
  float getConnectionUptime() const; // in seconds
  IPAddress getLocalIP() const;
  int getRSSI() const;

  // Smart WiFi Roaming configuration
  void enableSmartRoaming(bool enable = true);
  void setRoamingThreshold(int thresholdDbm = -75);
  void setRoamingCooldown(unsigned long cooldownSeconds = 120);
  void setRoamingImprovement(int improvementDbm = 10);
  bool isSmartRoamingEnabled() const;

  // MAC Address Filtering and Priority
  void setAccessPointMacFilter(const String& macAddress);   // Only connect to this MAC
  void setAccessPointMacPriority(const String& macAddress); // Prefer this MAC, fallback to others
  void clearMacFilter();                                    // Remove MAC filtering
  void clearMacPriority();                                  // Remove MAC priority
  bool isMacFilterEnabled() const;
  bool isMacPriorityEnabled() const;
  String getFilterMac() const;
  String getPriorityMac() const;

  // WiFi Stack Management
  void performStackReset(); // Complete WiFi stack reset for connectivity issues

  // Compatibility methods for ConfigManager
  bool getStatus() const {
    return isConnected();
  }
};

#endif // CM_ENABLE_WIFI
