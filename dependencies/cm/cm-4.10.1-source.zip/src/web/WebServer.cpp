#include "WebServer.h"
#include "../ConfigManager.h"
#include "../settings.h"
#include "WebRequestBodyBuffer.h"
#include "StaticGzipResponse.h"
#include "BoundedResponse.h"
#include "AppInfoJson.h"
#include "ThemeCssSnapshot.h"
#include "HttpHeapDiagnostics.h"
#include "../runtime/detail/LivePageSelection.h"

#include <AsyncJson.h>
#include <cstring>
#include <esp_heap_caps.h>
#include <new>
#include <utility>

// Logging support
#define WEB_LOG(...) CM_LOG("[Web] " __VA_ARGS__)
#define WEB_LOG_VERBOSE(...) CM_LOG_VERBOSE("[Web] " __VA_ARGS__)

namespace {

bool readLivePageSelection(AsyncWebServerRequest* request, ConfigManagerClass* manager, String& pageKey, bool& selected) {
  selected = request->hasParam("page");
  if (!selected)
    return true;
  const String& value = request->getParam("page")->value();
  if (!cm::validLivePageSelector(value.c_str(), value.length())) {
    request->send(400, "application/json", "{\"error\":\"invalid_page\"}");
    return false;
  }
  if (!manager || !manager->hasLivePageKey(value)) {
    request->send(404, "application/json", "{\"error\":\"unknown_page\"}");
    return false;
  }
  pageKey = value;
  return true;
}

void logRuntimeMetaResponseFailure(size_t payloadLength, uint32_t activeRequests) {
  WEB_LOG("[W] Runtime meta response unavailable: payload=%u active=%u free=%u min=%u largest=%u",
          static_cast<unsigned>(payloadLength),
          static_cast<unsigned>(activeRequests),
          static_cast<unsigned>(ESP.getFreeHeap()),
          static_cast<unsigned>(ESP.getMinFreeHeap()),
          static_cast<unsigned>(heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)));
}

} // namespace

ConfigManagerWeb::ConfigManagerWeb(AsyncWebServer* webServer)
    : server(webServer), configManager(nullptr), initialized(false), routesDefined(false), serverStarted(false), embedWebUI(CM_EMBED_WEBUI ? true : false), customHTML(nullptr), customHTMLLen(0), settingsPassword("") // Empty by default - only protect if explicitly set
{
  if (!server) {
    server = new AsyncWebServer(80);
  }
}

ConfigManagerWeb::~ConfigManagerWeb() {
  // Don't delete server here as it might be externally managed
}

namespace {
bool parseForceFlag(AsyncWebServerRequest* request) {
  if (!request) {
    return false;
  }
  AsyncWebParameter* param = nullptr;
  if (request->hasParam("force")) {
    param = request->getParam("force");
  } else if (request->hasParam("force", true)) {
    param = request->getParam("force", true);
  }

  if (!param) {
    return false;
  }

  String value = param->value();
  value.trim();
  value.toLowerCase();
  return value == "1" || value == "true" || value == "yes";
}

class RequestContextScope {
public:
  RequestContextScope(ConfigManagerClass* manager, const ConfigRequestContext& ctx)
      : manager(manager) {
    if (manager) {
      manager->pushRequestContext(ctx);
    }
  }

  ~RequestContextScope() {
    if (manager) {
      manager->popRequestContext();
    }
  }

private:
  ConfigManagerClass* manager = nullptr;
};
} // namespace

void ConfigManagerWeb::begin(ConfigManagerClass* cm) {
  configManager = cm;
  initialized = true;
  WEB_LOG("Web server module initialized");
}

void ConfigManagerWeb::setCallbacks(
  JsonProvider configJson,
  JsonProvider runtimeJson,
  RuntimeMetaProvider runtimeMetaJson,
  SimpleCallback reboot,
  SimpleCallback reset,
  SettingUpdateCallback settingUpdate,
  SettingUpdateCallback settingApply) {
#if CM_ENABLE_SETTINGS_UI
  configJsonProvider = configJson;
#endif
#if CM_ENABLE_LIVE_UI
  runtimeJsonProvider = runtimeJson;
  runtimeMetaJsonProvider = runtimeMetaJson;
#endif
  rebootCallback = reboot;
#if CM_ENABLE_SETTINGS_UI
  resetCallback = reset;
  settingUpdateCallback = settingUpdate;
  settingApplyCallback = settingApply;
#endif
}

void ConfigManagerWeb::setCallbacks(
  JsonProvider configJson,
  JsonProvider runtimeJson,
  JsonProvider runtimeMetaJson,
  SimpleCallback reboot,
  SimpleCallback reset,
  SettingUpdateCallback settingUpdate,
  SettingUpdateCallback settingApply) {
  setCallbacks(
    std::move(configJson),
    std::move(runtimeJson),
    [runtimeMetaJson = std::move(runtimeMetaJson)]() mutable -> std::shared_ptr<const String> {
      String json = runtimeMetaJson ? runtimeMetaJson() : String();
      if (json.length() == 0) {
        return nullptr;
      }
      return std::make_shared<String>(std::move(json));
    },
    std::move(reboot),
    std::move(reset),
    std::move(settingUpdate),
    std::move(settingApply));
}

void ConfigManagerWeb::setEmbedWebUI(bool embed) {
  embedWebUI = embed;
}

void ConfigManagerWeb::setCustomHTML(const char* html, size_t length) {
  customHTML = html;
  customHTMLLen = length;
}

bool ConfigManagerWeb::isStarted() const {
  return initialized && server;
}

void ConfigManagerWeb::defineAllRoutes() {
  if (!initialized || !server) {
    WEB_LOG("[W] Cannot define routes - not initialized");
    return;
  }

  if (!routesDefined) {
    setupStaticRoutes();
    setupAPIRoutes();
#if CM_ENABLE_LIVE_UI
    setupRuntimeRoutes();
#endif
    routesDefined = true;

    WEB_LOG("[I] All routes defined");
  } else {
    WEB_LOG_VERBOSE("[D] Routes already defined");
  }

  if (!serverStarted) {
    server->begin();
    serverStarted = true;
    WEB_LOG("[I] Server started on port 80");
  } else {
    WEB_LOG_VERBOSE("[D] Server already started");
  }
}

void ConfigManagerWeb::setupStaticRoutes() {
  // Root route
  server->on("/", HTTP_GET, [this](AsyncWebServerRequest* request) {
    handleRootRequest(request);
  });

  // CSS and JS routes
  server->on("/style.css", HTTP_GET, [this](AsyncWebServerRequest* request) {
    handleCSSRequest(request);
  });

  server->on("/script.js", HTTP_GET, [this](AsyncWebServerRequest* request) {
    handleJSRequest(request);
  });

  // Optional user theme CSS injection
  server->on("/user_theme.css", HTTP_GET, [this](AsyncWebServerRequest* request) {
    CM_HTTP_HEAP_TRACE("/user_theme.css", "start");
    // Custom CSS belongs to the app. Built-in CSS is immutable static storage.
    const char* css = nullptr;
    size_t len = 0;
    if (configManager) {
      css = configManager->getCustomCss();
      len = configManager->getCustomCssLen();
    }

    bool usingBuiltin = false;
#if CM_ENABLE_THEMING
    if (!css) {
      css = CM_DEFAULT_RUNTIME_STYLE_CSS;
      len = sizeof(CM_DEFAULT_RUNTIME_STYLE_CSS) - 1;
      usingBuiltin = true;
    }
#endif
    // Preserve the stream's zero-length/empty behavior and built-in fallback.
    const size_t bodyLength = css ? (len ? len : (usingBuiltin ? std::strlen(css) : 0)) : 0;
    String ownedCss;
    if (!usingBuiltin && !cm::snapshotThemeCss(css, bodyLength, ownedCss)) {
      CM_HTTP_HEAP_TRACE("/user_theme.css", "body-failed");
      if (request->client())
        request->client()->close();
      return;
    }
    CM_HTTP_HEAP_TRACE("/user_theme.css", "body-ready");
    // Avoid the response stream's default 1460-byte buffer. Borrow only static
    // data; move the custom snapshot so later app changes cannot alter the body.
    // nothrow does not protect allocations inside the constructor or headers.
    cm::BoundedResponse* response = usingBuiltin
                                      ? new (std::nothrow) cm::BoundedResponse(reinterpret_cast<const uint8_t*>(css), bodyLength, "text/css")
                                      : new (std::nothrow) cm::BoundedResponse(std::move(ownedCss), "text/css");
    if (!response) {
      CM_HTTP_HEAP_TRACE("/user_theme.css", "response-failed");
      if (request->client())
        request->client()->close();
      return;
    }
    CM_HTTP_HEAP_TRACE("/user_theme.css", "response-ready");
    response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response->addHeader("Pragma", "no-cache");
    response->addHeader("Expires", "0");
    CM_HTTP_HEAP_TRACE("/user_theme.css", "send");
    request->send(response);
  });

  // Favicon
  server->on("/favicon.ico", HTTP_GET, [](AsyncWebServerRequest* request) {
    request->send(404);
  });

  // Minimal captive-portal compatibility probes. They redirect only while
  // the device is in AP/setup mode; STA/runtime mode keeps normal 404s.
  server->on("/generate_204", HTTP_GET, [this](AsyncWebServerRequest* request) {
    handleCaptivePortalProbe(request);
  });

  server->on("/canonical.html", HTTP_GET, [this](AsyncWebServerRequest* request) {
    handleCaptivePortalProbe(request);
  });

  // 404 handler
  server->onNotFound([this](AsyncWebServerRequest* request) {
    handleNotFound(request);
  });
}

void ConfigManagerWeb::setupAPIRoutes() {
  // Simple version endpoint consumed by the UI header
  server->on("/version", HTTP_GET, [this](AsyncWebServerRequest* request) {
    String payload;
    if (configManager) {
      payload = configManager->getAppName();
    }
    if (payload.length() == 0) {
      payload = String("ConfigManager"); // Fallback if no app name set
    }
    if (payload.length())
      payload += " ";

    // Get version from ConfigManager
    String version;
    if (configManager) {
      version = configManager->getVersion();
    }
    if (version.length() == 0) {
      version = String(""); // Fallback if no version set
    }
    payload += version;

    request->send(200, "text/plain", payload);
  });

  // App info endpoint (JSON) consumed by the WebUI.
  // Allows separate H1 (appName) and browser tab title (appTitle).
  server->on("/appinfo", HTTP_GET, [this](AsyncWebServerRequest* request) {
    CM_HTTP_HEAP_TRACE("/appinfo", "start");
    const String empty;
    // Getters return references. The app metadata must remain stable during the
    // two immediate serialization passes, as with the existing getter API.
    const String& appName = (configManager && configManager->getAppName().length()) ? configManager->getAppName() : empty;
    const String& appTitle = (configManager && configManager->getAppTitle().length()) ? configManager->getAppTitle() : empty;
    const String& version = (configManager && configManager->getVersion().length()) ? configManager->getVersion() : empty;
    const bool guiLogging = configManager && configManager->isGuiLoggingEnabled();
    String payload;
    if (!cm::buildAppInfoJson(appName, appTitle, version, guiLogging, payload)) {
      CM_HTTP_HEAP_TRACE("/appinfo", "json-failed");
      // An allocation failure must not trigger another allocating error response.
      if (request->client())
        request->client()->close();
      return;
    }

    CM_HTTP_HEAP_TRACE("/appinfo", "json-ready");
    // nothrow covers the response object only. Constructor/header allocations
    // still depend on the underlying web server's allocation behavior.
    auto* response = new (std::nothrow) cm::BoundedResponse(std::move(payload), "application/json");
    if (!response) {
      if (request->client())
        request->client()->close();
      return;
    }
    CM_HTTP_HEAP_TRACE("/appinfo", "response-ready");
    enableCORS(response, "/appinfo");
    CM_HTTP_HEAP_TRACE("/appinfo", "send");
    request->send(response);
  });
  server->on("/ui_capabilities", HTTP_GET, [this](AsyncWebServerRequest* request) {
    const auto* ota = configManager ? &configManager->getOTAManager() : nullptr;
    char body[256];
    snprintf(body, sizeof(body), "{\"live\":%s,\"settings\":%s,\"otaEnabled\":%s,\"otaActive\":%s,\"otaHasPassword\":%s,\"settingsAuthRequired\":%s}", CM_ENABLE_LIVE_UI ? "true" : "false", CM_ENABLE_SETTINGS_UI ? "true" : "false", ota && ota->isEnabled() ? "true" : "false", ota && ota->isActive() ? "true" : "false", ota && ota->hasPassword() ? "true" : "false", isSettingsAuthRequired() ? "true" : "false");
    auto* response = request->beginResponse(200, "application/json", body);
    response->addHeader("Cache-Control", "no-store");
    enableCORS(response);
    request->send(response);
  });

#if CM_ENABLE_SETTINGS_UI
  // Debug route to catch any config requests with body handling
  server->on("/config_raw", HTTP_ANY, [this](AsyncWebServerRequest* request) {
            // Response sent in body handler for POST requests
            if (request->method() != HTTP_POST) {
                request->send(405, "application/json", "{\"error\":\"method_not_allowed\"}");
            // Cppcheck rationale: AsyncWebServer defines this body callback's mutable data parameter.
            // cppcheck-suppress constParameterPointer
            } }, NULL, [this](AsyncWebServerRequest* request, uint8_t* data, size_t len, size_t index, size_t total) {
            String* body = cm::web::appendRequestBodyChunk(request, data, len, index, total);
            if (!body) {
                return;
            }

            if (index + len == total) {
                WEB_LOG_VERBOSE("config_raw done: params=%d bodyLen=%u",
                                request->params(), static_cast<unsigned>(body->length()));

                // Check for new format: category + key as URL params, value in JSON body
                bool hasCategory = request->hasParam("category");
                bool hasKey = request->hasParam("key");

                if (hasCategory && hasKey) {
                    String category = request->getParam("category")->value();
                    String key = request->getParam("key")->value();

                    // Parse JSON body to get value
                    DynamicJsonDocument doc(256);
                    DeserializationError err = deserializeJson(doc, *body);

                    String value;
                    if (!err && doc.containsKey("value")) {
                        if (doc["value"].is<String>()) {
                            value = doc["value"].as<String>();
                        } else {
                            // Convert other types to string
                            serializeJson(doc["value"], value);
                        }
                    } else {
                        // Fallback: use entire body as value
                        value = *body;
                        // Remove quotes if it's a JSON string
                        if (value.startsWith("\"") && value.endsWith("\"")) {
                            value = value.substring(1, value.length() - 1);
                        }
                    }

                    WEB_LOG_VERBOSE("config_raw parsed: %s.%s", category.c_str(), key.c_str());

                    // Passwords are transmitted in plaintext over HTTP.
                    String finalValue = value;
                    
                    if (settingUpdateCallback && settingUpdateCallback(category, key, finalValue)) {
                        request->send(200, "application/json", "{\"status\":\"ok\"}");
                    } else {
                        request->send(400, "application/json", "{\"status\":\"error\",\"reason\":\"update_failed\"}");
                    }
                } else {
                    WEB_LOG_VERBOSE("config_raw missing params: category=%s key=%s",
                                    hasCategory ? "yes" : "no", hasKey ? "yes" : "no");
                    request->send(400, "application/json", "{\"status\":\"error\",\"reason\":\"missing_url_params\"}");
                }

                cm::web::clearRequestBodyBuffer(request);
            } });

  // Configuration endpoints
  server->on("/config.json", HTTP_GET, [this](AsyncWebServerRequest* request) {
    if (configJsonProvider) {
      try {
        String json = configJsonProvider();
        size_t jsonSize = json.length();

        // Log the JSON size for debugging
        WEB_LOG_VERBOSE("config.json size=%u", (unsigned)jsonSize);

        // Reject an empty provider result.
        if (jsonSize == 0) {
          WEB_LOG("Error: Generated JSON is empty!");
          request->send(500, "application/json", "{\"error\":\"empty_json\"}");
          return;
        }

        AsyncWebServerResponse* response = new (std::nothrow) cm::BoundedResponse(std::move(json), "application/json");
        if (!response) {
          WEB_LOG("Error: Response allocation failed for config.json");
          request->send(500, "application/json", "{\"error\":\"response_alloc_failed\"}");
          return;
        }
        enableCORS(response);
        request->send(response);

        WEB_LOG_VERBOSE("config.json sent (%u)", (unsigned)jsonSize);
      } catch (const std::exception& e) {
        WEB_LOG("Exception in config.json: %s", e.what());
        request->send(500, "application/json", "{\"error\":\"json_generation_failed\"}");
      } catch (...) {
        WEB_LOG("Unknown exception in config.json generation");
        request->send(500, "application/json", "{\"error\":\"unknown_error\"}");
      }
    } else {
      request->send(500, "application/json", "{\"error\":\"no_provider\"}");
    }
  });

#endif
#if CM_ENABLE_LIVE_UI
  server->on("/live_pages.json", HTTP_GET, [this](AsyncWebServerRequest* request) {
    CM_HTTP_HEAP_TRACE("/live_pages.json", "start");
    if (!configManager) {
      request->send(404, "application/json", "{\"error\":\"no_config\"}");
      return;
    }
    String json = configManager->buildLivePageIndexJSON();
    CM_HTTP_HEAP_TRACE("/live_pages.json", "json-ready");
    if (!json.length()) {
      request->send(503, "application/json", "{\"error\":\"pages_unavailable\"}");
      return;
    }
    auto* response = new (std::nothrow) cm::BoundedResponse(std::move(json), "application/json");
    if (!response) {
      request->send(503, "application/json", "{\"error\":\"pages_unavailable\"}");
      return;
    }
    CM_HTTP_HEAP_TRACE("/live_pages.json", "response-ready");
    enableCORS(response, "/live_pages.json");
    response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    CM_HTTP_HEAP_TRACE("/live_pages.json", "send");
    request->send(response);
  });

  server->on("/live_layout.json", HTTP_GET, [this](AsyncWebServerRequest* request) {
    if (!configManager) {
      request->send(500, "application/json", "{\"error\":\"no_config\"}");
      return;
    }
    String pageKey;
    bool selected = false;
    // Invalid selectors send 400; missing managers or unknown page keys send 404.
    // cppcheck-suppress knownConditionTrueFalse
    if (!readLivePageSelection(request, configManager, pageKey, selected))
      return;
    String json = selected ? configManager->buildLiveLayoutJSON(pageKey) : configManager->buildLiveLayoutJSON();
    if (json.length() == 0) {
      request->send(503, "application/json", "{\"error\":\"layout_unavailable\"}");
      return;
    }
    AsyncWebServerResponse* response = new (std::nothrow) cm::BoundedResponse(std::move(json), "application/json");
    if (!response) {
      request->send(500, "application/json", "{\"error\":\"response_alloc_failed\"}");
      return;
    }
    enableCORS(response);
    request->send(response);
  });

#endif
#if CM_ENABLE_SETTINGS_UI
  // Settings update endpoint - /config/apply (matches frontend expectations)
  // Use AsyncCallbackJsonWebHandler to avoid edge cases with raw body accumulation.
  {
    auto* handler = new AsyncCallbackJsonWebHandler("/config/apply", [this](AsyncWebServerRequest* request, JsonVariant& json) {
      WEB_LOG_VERBOSE("/config/apply request");

      const String category = request->hasParam("category") ? request->getParam("category")->value() : "";
      const String key = request->hasParam("key") ? request->getParam("key")->value() : "";
      if (category.isEmpty() || key.isEmpty()) {
        WEB_LOG_VERBOSE("/config/apply missing URL params");
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"apply\",\"reason\":\"missing_params\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      if (!json.is<JsonObject>()) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"apply\",\"reason\":\"invalid_json\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      JsonObject obj = json.as<JsonObject>();
      String requestPayload;
      serializeJson(obj, requestPayload);
      if (!obj.containsKey("value")) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"apply\",\"reason\":\"missing_value\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      String value;
      JsonVariant v = obj["value"];
      if (v.is<const char*>()) {
        value = v.as<String>();
      } else if (v.is<bool>()) {
        value = v.as<bool>() ? "true" : "false";
      } else if (v.is<int>()) {
        value = String(v.as<int>());
      } else if (v.is<float>()) {
        value = String(v.as<float>(), 6);
      } else {
        serializeJson(v, value);
      }

      WEB_LOG_VERBOSE("/config/apply %s.%s", category.c_str(), key.c_str());

      // Passwords are transmitted in plaintext over HTTP.
      const String finalValue = value;

      bool success = false;
      if (settingApplyCallback) {
        ConfigRequestContext ctx;
        ctx.origin = ConfigRequestContext::Origin::ApplySingle;
        ctx.endpoint = request->url();
        ctx.payload = requestPayload;
        ctx.force = parseForceFlag(request);
        RequestContextScope scope(configManager, ctx);
        success = settingApplyCallback(category, key, finalValue);
      }

      if (success) {
        const String payload = String("{\"status\":\"ok\",\"action\":\"apply\",\"category\":\"") +
                               category + "\",\"key\":\"" + key + "\"}";
        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", payload);
        enableCORS(response);
        request->send(response);
      } else {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"apply\",\"reason\":\"update_failed\"}");
        enableCORS(response);
        request->send(response);
      }
    });
    handler->setMethod(HTTP_POST);
    server->addHandler(handler);
  }

#endif
#if CM_ENABLE_LIVE_UI || CM_ENABLE_SETTINGS_UI
  server->on("/gui/action", HTTP_POST, [this](AsyncWebServerRequest* request) {
    auto readParam = [request](const char* name) -> String {
      AsyncWebParameter* param = request->getParam(name, false);
      if (!param) {
        param = request->getParam(name, true);
      }
      return param ? param->value() : String();
    };

    const String actionId = readParam("actionId");
    const String messageId = readParam("messageId");
    bool handled = false;
    if (configManager) {
      handled = configManager->handleGuiAction(messageId, actionId);
    }
    const String body = String("{\"status\":\"") + (handled ? "ok" : "error") + "\"}";
    AsyncWebServerResponse* response = request->beginResponse(handled ? 200 : 400, "application/json", body);
    enableCORS(response);
    request->send(response);
  });

#endif
#if CM_ENABLE_SETTINGS_UI
  // Settings save endpoint - /config/save (saves individual setting to flash)
  // Use AsyncCallbackJsonWebHandler to avoid edge cases with chunked/unknown body sizes.
  {
    auto* handler = new AsyncCallbackJsonWebHandler("/config/save", [this](AsyncWebServerRequest* request, JsonVariant& json) {
      WEB_LOG_VERBOSE("/config/save request");

      const String category = request->hasParam("category") ? request->getParam("category")->value() : "";
      const String key = request->hasParam("key") ? request->getParam("key")->value() : "";
      if (category.isEmpty() || key.isEmpty()) {
        WEB_LOG_VERBOSE("/config/save missing URL params");
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"save\",\"reason\":\"missing_params\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      if (!json.is<JsonObject>()) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"save\",\"reason\":\"invalid_json\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      JsonObject obj = json.as<JsonObject>();
      String requestPayload;
      serializeJson(obj, requestPayload);
      String value;
      if (obj.containsKey("value")) {
        JsonVariant v = obj["value"];
        if (v.is<const char*>()) {
          value = v.as<String>();
        } else if (v.is<bool>()) {
          value = v.as<bool>() ? "true" : "false";
        } else if (v.is<int>()) {
          value = String(v.as<int>());
        } else if (v.is<float>()) {
          value = String(v.as<float>(), 6);
        } else {
          serializeJson(v, value);
        }
      } else {
        // Backwards-compatible fallback
        value = "";
      }

      WEB_LOG("Processing /config/save: category='%s', key='%s'", category.c_str(), key.c_str());
      WEB_LOG("Extracted value for save: '%s'", value.c_str());

      // Passwords are transmitted in plaintext over HTTP.
      const String finalValue = value;

      bool success = false;
      if (settingUpdateCallback) {
        ConfigRequestContext ctx;
        ctx.origin = ConfigRequestContext::Origin::SaveSingle;
        ctx.endpoint = request->url();
        ctx.payload = requestPayload;
        ctx.force = parseForceFlag(request);
        RequestContextScope scope(configManager, ctx);
        success = settingUpdateCallback(category, key, finalValue);
      }

      if (success) {
        if (configManager) {
          // Cppcheck rationale: Avoid changing mutable Arduino integration handles without a call-site audit.
          // cppcheck-suppress constVariablePointer
          BaseSetting* setting = configManager->findSetting(category, key);
          if (setting) {
            WEB_LOG_VERBOSE("[D] Saved setting: %s.%s key=%s",
                            setting->getCategory(),
                            setting->getDisplayName(),
                            setting->getKey());
          } else {
            WEB_LOG_VERBOSE("[D] Saved setting: %s.%s", category.c_str(), key.c_str());
          }
        }
        const String payload = String("{\"status\":\"ok\",\"action\":\"save\",\"category\":\"") +
                               category + "\",\"key\":\"" + key + "\"}";
        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", payload);
        enableCORS(response);
        request->send(response);
      } else {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"action\":\"save\",\"reason\":\"update_failed\"}");
        enableCORS(response);
        request->send(response);
      }
    });
    handler->setMethod(HTTP_POST);
    server->addHandler(handler);
  }

#endif
  // Settings authentication endpoint - /config/auth
  // Issues a short-lived token required for password reveal.
  // Use AsyncCallbackJsonWebHandler to avoid edge cases with chunked/unknown body sizes.
  {
    auto* handler = new AsyncCallbackJsonWebHandler("/config/auth", [this](AsyncWebServerRequest* request, JsonVariant& json) {
      WEB_LOG_VERBOSE("/config/auth request");

      if (!json.is<JsonObject>()) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"reason\":\"invalid_json\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      JsonObject obj = json.as<JsonObject>();
      const String provided = obj.containsKey("password") ? obj["password"].as<String>() : String("");
      const bool required = isSettingsAuthRequired();
      const bool match = (!required) || (provided == settingsPassword);
      WEB_LOG("/config/auth required=%s providedLen=%d configuredLen=%d match=%s",
              required ? "true" : "false",
              (int)provided.length(),
              (int)settingsPassword.length(),
              match ? "true" : "false");

      if (match) {
        const String token = issueSettingsAuthToken();
        DynamicJsonDocument out(256);
        out["status"] = "ok";
        out["token"] = token;
        out["ttlSec"] = (int)(SETTINGS_AUTH_TTL_MS / 1000UL);
        String resp;
        serializeJson(out, resp);

        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", resp);
        enableCORS(response);
        request->send(response);
      } else {
        AsyncWebServerResponse* response = request->beginResponse(403, "application/json", "{\"status\":\"error\",\"reason\":\"unauthorized\"}");
        enableCORS(response);
        request->send(response);
      }
    });
    handler->setMethod(HTTP_POST);
    server->addHandler(handler);
  }

#if CM_ENABLE_SETTINGS_UI
  // Password fetch endpoint - /config/password (returns actual password value)
  // Requires a valid auth token returned by /config/auth.
  server->on("/config/password", HTTP_GET, [this](AsyncWebServerRequest* request) {
    if (!isSettingsAuthValid(request)) {
      request->send(403, "application/json", "{\"status\":\"error\",\"reason\":\"unauthorized\"}");
      return;
    }

    const String category = request->hasParam("category") ? request->getParam("category")->value() : "";
    const String key = request->hasParam("key") ? request->getParam("key")->value() : "";

    if (category.isEmpty() || key.isEmpty()) {
      request->send(400, "application/json", "{\"status\":\"error\",\"reason\":\"missing_params\"}");
      return;
    }

    if (!configManager) {
      request->send(500, "application/json", "{\"status\":\"error\",\"reason\":\"not_initialized\"}");
      return;
    }

    BaseSetting* s = configManager->findSetting(category, key);
    if (!s || !s->isSecret()) {
      request->send(404, "application/json", "{\"status\":\"error\",\"reason\":\"not_found\"}");
      return;
    }

    if (s->getType() != SettingType::STRING) {
      request->send(400, "application/json", "{\"status\":\"error\",\"reason\":\"not_string_password\"}");
      return;
    }

    // Cppcheck rationale: Avoid changing mutable Arduino integration handles without a call-site audit.
    // cppcheck-suppress constVariablePointer
    auto* cs = static_cast<Config<String>*>(s);

    DynamicJsonDocument out(512);
    out["status"] = "ok";
    out["value"] = cs->get();
    String resp;
    serializeJson(out, resp);
    request->send(200, "application/json", resp);
  });

  // Legacy endpoint (deprecated): /config/settings_password
  // Never return the configured password.
  server->on("/config/settings_password", HTTP_GET, [this](AsyncWebServerRequest* request) {
    AsyncWebServerResponse* response = request->beginResponse(
      410,
      "application/json",
      "{\"status\":\"error\",\"reason\":\"deprecated\"}");
    enableCORS(response);
    request->send(response);
  });

  // Bulk apply endpoint - /config/apply_all (applies all settings to memory only)
  // Use AsyncCallbackJsonWebHandler to avoid edge cases with chunked/unknown body sizes.
  {
    auto* handler = new AsyncCallbackJsonWebHandler("/config/apply_all", [this](AsyncWebServerRequest* request, JsonVariant& json) {
      WEB_LOG_VERBOSE("/config/apply_all request");

      if (!json.is<JsonObject>()) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"reason\":\"invalid_json\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      bool allSuccess = true;
      int totalApplied = 0;

      const bool forceFlag = parseForceFlag(request);
      JsonObject root = json.as<JsonObject>();
      for (JsonPair categoryPair : root) {
        const String category = categoryPair.key().c_str();
        if (!categoryPair.value().is<JsonObject>()) {
          allSuccess = false;
          continue;
        }

        JsonObject categoryObj = categoryPair.value().as<JsonObject>();
        for (JsonPair settingPair : categoryObj) {
          const String key = settingPair.key().c_str();
          const JsonVariant v = settingPair.value();

          String value;
          if (v.is<const char*>()) {
            value = v.as<String>();
          } else if (v.is<bool>()) {
            value = v.as<bool>() ? "true" : "false";
          } else if (v.is<int>()) {
            value = String(v.as<int>());
          } else if (v.is<float>()) {
            value = String(v.as<float>(), 6);
          } else {
            serializeJson(v, value);
          }

          String requestPayload;
          {
            StaticJsonDocument<128> payloadDoc;
            payloadDoc["value"] = v;
            serializeJson(payloadDoc, requestPayload);
          }

          bool callResult = false;
          if (settingApplyCallback) {
            ConfigRequestContext ctx;
            ctx.origin = ConfigRequestContext::Origin::ApplyAll;
            ctx.endpoint = request->url();
            ctx.payload = requestPayload;
            ctx.force = forceFlag;
            RequestContextScope scope(configManager, ctx);
            callResult = settingApplyCallback(category, key, value);
          }

          if (callResult) {
            totalApplied++;
            WEB_LOG("Applied %s.%s = %s", category.c_str(), key.c_str(), value.c_str());
          } else {
            allSuccess = false;
            WEB_LOG("Failed to apply %s.%s = %s", category.c_str(), key.c_str(), value.c_str());
          }
        }
      }

      if (allSuccess && totalApplied > 0) {
        const String payload = String("{\"status\":\"ok\",\"action\":\"apply_all\",\"applied\":") + String(totalApplied) + "}";
        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", payload);
        enableCORS(response);
        request->send(response);
      } else {
        const String payload = String("{\"status\":\"error\",\"action\":\"apply_all\",\"applied\":") + String(totalApplied) + "}";
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", payload);
        enableCORS(response);
        request->send(response);
      }
    });
    handler->setMethod(HTTP_POST);
    server->addHandler(handler);
  }

  // Bulk save endpoint - /config/save_all (saves all settings to flash)
  // Use AsyncCallbackJsonWebHandler to avoid edge cases with chunked/unknown body sizes.
  {
    auto* handler = new AsyncCallbackJsonWebHandler("/config/save_all", [this](AsyncWebServerRequest* request, JsonVariant& json) {
      WEB_LOG("Processing /config/save_all");

      if (!json.is<JsonObject>()) {
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", "{\"status\":\"error\",\"reason\":\"invalid_json\"}");
        enableCORS(response);
        request->send(response);
        return;
      }

      bool allSuccess = true;
      int totalSaved = 0;

      const bool forceFlag = parseForceFlag(request);
      JsonObject root = json.as<JsonObject>();
      for (JsonPair categoryPair : root) {
        const String category = categoryPair.key().c_str();
        if (!categoryPair.value().is<JsonObject>()) {
          allSuccess = false;
          continue;
        }

        JsonObject categoryObj = categoryPair.value().as<JsonObject>();
        for (JsonPair settingPair : categoryObj) {
          const String key = settingPair.key().c_str();
          const JsonVariant v = settingPair.value();

          String value;
          if (v.is<const char*>()) {
            value = v.as<String>();
          } else if (v.is<bool>()) {
            value = v.as<bool>() ? "true" : "false";
          } else if (v.is<int>()) {
            value = String(v.as<int>());
          } else if (v.is<float>()) {
            value = String(v.as<float>(), 6);
          } else {
            serializeJson(v, value);
          }

          String requestPayload;
          {
            StaticJsonDocument<128> payloadDoc;
            payloadDoc["value"] = v;
            serializeJson(payloadDoc, requestPayload);
          }

          bool callResult = false;
          if (settingUpdateCallback) {
            ConfigRequestContext ctx;
            ctx.origin = ConfigRequestContext::Origin::SaveAll;
            ctx.endpoint = request->url();
            ctx.payload = requestPayload;
            ctx.force = forceFlag;
            RequestContextScope scope(configManager, ctx);
            callResult = settingUpdateCallback(category, key, value);
          }

          if (callResult) {
            totalSaved++;
            WEB_LOG("Saved %s.%s = %s", category.c_str(), key.c_str(), value.c_str());
          } else {
            allSuccess = false;
            WEB_LOG("Failed to save %s.%s = %s", category.c_str(), key.c_str(), value.c_str());
          }
        }
      }

      if (allSuccess && totalSaved > 0) {
        const String payload = String("{\"status\":\"ok\",\"action\":\"save_all\",\"saved\":") + String(totalSaved) + "}";
        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", payload);
        enableCORS(response);
        request->send(response);
      } else {
        const String payload = String("{\"status\":\"error\",\"action\":\"save_all\",\"saved\":") + String(totalSaved) + "}";
        AsyncWebServerResponse* response = request->beginResponse(400, "application/json", payload);
        enableCORS(response);
        request->send(response);
      }
    });
    handler->setMethod(HTTP_POST);
    server->addHandler(handler);
  }

  // Reset to defaults
  server->on("/config/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
    if (resetCallback) {
      resetCallback();
      request->send(200, "application/json", "{\"status\":\"reset\"}");
    } else {
      request->send(500, "application/json", "{\"error\":\"no_callback\"}");
    }
  });

#endif
  // Reboot endpoint
  server->on("/reboot", HTTP_POST, [this](AsyncWebServerRequest* request) {
    AsyncWebServerResponse* response = request->beginResponse(200, "application/json", "{\"status\":\"rebooting\"}");
    response->addHeader("Connection", "close");
    request->send(response);

    if (rebootCallback) {
      // Delay the reboot slightly to allow response to be sent
      rebootCallback();
    }
  });
}

void ConfigManagerWeb::handleRootRequest(AsyncWebServerRequest* request) {
  const uint8_t* content = nullptr;
  size_t length = 0;
  if (customHTML && customHTMLLen > 0) {
    content = reinterpret_cast<const uint8_t*>(customHTML);
    length = customHTMLLen;
  } else if (embedWebUI) {
#if CM_EMBED_WEBUI
    WebHTML webhtml;
    content = webhtml.getWebHTMLGz();
    length = webhtml.getWebHTMLGzLen();
#else
    request->send(404, "text/html", "<h1>WebUI not embedded</h1><p>This firmware was built with CM_EMBED_WEBUI=0</p>");
    return;
#endif
  } else {
    request->send(404, "text/html", "<h1>No WebUI configured</h1>");
    return;
  }
  auto* response = new (std::nothrow) cm::StaticGzipResponse(content, length);
  if (!response) {
    request->send(503, "text/plain", "WebUI temporarily unavailable");
    return;
  }
  request->send(response);
}

void ConfigManagerWeb::handleCSSRequest(AsyncWebServerRequest* request) {
#if CM_EMBED_WEBUI
  // CSS is embedded in the main HTML file
  request->send(404, "text/css", "/* CSS embedded in HTML */");
#else
  request->send(404, "text/css", "/* CSS not embedded */");
#endif
}

void ConfigManagerWeb::handleJSRequest(AsyncWebServerRequest* request) {
#if CM_EMBED_WEBUI
  // JS is embedded in the main HTML file
  request->send(404, "application/javascript", "/* JS embedded in HTML */");
#else
  request->send(404, "application/javascript", "/* JS not embedded */");
#endif
}

void ConfigManagerWeb::handleNotFound(AsyncWebServerRequest* request) {
  if (shouldRedirectToPortal(request)) {
    WEB_LOG_VERBOSE("[D] Captive portal redirect: %s",
                    request->url().c_str());
    redirectToPortalRoot(request);
    return;
  }

  WEB_LOG("404: %s %s",
          request->methodToString(),
          request->url().c_str());
  request->send(404, "text/plain", "Not Found");
}

void ConfigManagerWeb::handleCaptivePortalProbe(AsyncWebServerRequest* request) {
  if (isCaptivePortalMode()) {
    redirectToPortalRoot(request);
    return;
  }

  handleNotFound(request);
}

bool ConfigManagerWeb::isCaptivePortalMode() const {
#if CM_ENABLE_WIFI
  if (configManager && configManager->getWiFiManager().isInAPMode()) {
    return true;
  }

  const WiFiMode_t mode = WiFi.getMode();
  if (mode == WIFI_AP) {
    return true;
  }

  return mode == WIFI_AP_STA && WiFi.status() != WL_CONNECTED;
#else
  return false;
#endif
}

bool ConfigManagerWeb::shouldRedirectToPortal(AsyncWebServerRequest* request) const {
  if (!request || !isCaptivePortalMode()) {
    return false;
  }

  const WebRequestMethodComposite method = request->method();
  if (method != HTTP_GET && method != HTTP_HEAD) {
    return false;
  }

  const String path = request->url();
  if (path.isEmpty() || path == "/") {
    return false;
  }

  const char* reservedPrefixes[] = {
    "/appinfo",
    "/config",
    "/gui",
    "/live_layout.json",
    "/ota_update",
    "/reboot",
    "/runtime",
    "/runtime_action",
    "/script.js",
    "/style.css",
    "/user_theme.css",
    "/version",
    "/ws",
  };

  for (const char* prefix : reservedPrefixes) {
    if (path.startsWith(prefix)) {
      return false;
    }
  }

  return true;
}

// Cppcheck rationale: Preserve the existing instance API for source compatibility.
// cppcheck-suppress functionStatic
void ConfigManagerWeb::redirectToPortalRoot(AsyncWebServerRequest* request) {
  AsyncWebServerResponse* response = request->beginResponse(302, "text/plain", "Redirecting to setup portal");
  response->addHeader("Location", "/");
  response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  response->addHeader("Pragma", "no-cache");
  response->addHeader("Expires", "0");
  request->send(response);
}

void ConfigManagerWeb::addCustomRoute(const char* path, WebRequestMethodComposite method, RequestHandler handler) {
  if (server) {
    server->on(path, method, handler);
  }
}

// Cppcheck rationale: Preserve the existing instance API for source compatibility.
// cppcheck-suppress functionStatic
void ConfigManagerWeb::enableCORS(AsyncWebServerResponse* response, const char* diagnosticRoute) {
  if (!response) {
    return;
  }
  if (diagnosticRoute) {
    CM_HTTP_HEAP_TRACE(diagnosticRoute, "cors-origin");
  }
  response->addHeader("Access-Control-Allow-Origin", "*");
  if (diagnosticRoute) {
    CM_HTTP_HEAP_TRACE(diagnosticRoute, "cors-methods");
  }
  response->addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if (diagnosticRoute) {
    CM_HTTP_HEAP_TRACE(diagnosticRoute, "cors-headers");
  }
  response->addHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Settings-Token");
}

void ConfigManagerWeb::enableCORSForAll(bool enable) {
  if (enable && server) {
    server->onNotFound([this](AsyncWebServerRequest* request) {
      if (request->method() == HTTP_OPTIONS) {
        AsyncWebServerResponse* response = request->beginResponse(200);
        enableCORS(response);
        request->send(response);
      } else {
        handleNotFound(request);
      }
    });
  }
}

#if defined(development)
void ConfigManagerWeb::addDevelopmentRoutes() {
#if CM_ENABLE_SETTINGS_UI
  WEB_LOG("Adding development routes");

  // Development export route
  server->on("/dev/export", HTTP_GET, [this](AsyncWebServerRequest* request) {
    if (configJsonProvider) {
      String json = configJsonProvider();
      AsyncWebServerResponse* response = request->beginResponse(200, "application/json", json);
      response->addHeader("Content-Disposition", "attachment; filename=\"config_export.json\"");
      enableCORS(response);
      request->send(response);
    } else {
      request->send(500, "application/json", "{\"error\":\"no_provider\"}");
    }
  });
#endif
}
#endif

void ConfigManagerWeb::setupRuntimeRoutes() {
#if CM_ENABLE_LIVE_UI
  WEB_LOG("Setting up runtime routes");

  // Runtime JSON endpoint
  server->on("/runtime.json", HTTP_GET, [this](AsyncWebServerRequest* request) {
    cm::RuntimeSelection selection = cm::RuntimeSelection::everything();
    const bool selected = request->hasParam("groups");
    if (selected) {
      const String& value = request->getParam("groups")->value();
      if (value.length() > cm::RuntimeSelection::maxPayloadBytes || !cm::parseRuntimeSelection(value.c_str(), selection)) {
        request->send(400, "application/json", "{\"error\":\"invalid_runtime_selection\"}");
        return;
      }
    }
    if (runtimeJsonProvider || (selected && selectedRuntimeJsonProvider)) {
      // A standalone legacy callback has no selective interface and retains full semantics.
      String json = selected && selectedRuntimeJsonProvider ? selectedRuntimeJsonProvider(selection) : runtimeJsonProvider();
      if (!json.length()) {
        request->send(503, "application/json", "{\"error\":\"runtime_unavailable\"}");
        return;
      }
      AsyncWebServerResponse* response = new (std::nothrow) cm::BoundedResponse(std::move(json), "application/json");
      if (!response) {
        request->send(503, "application/json", "{\"error\":\"runtime_unavailable\"}");
        return;
      }
      enableCORS(response);
      response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      response->addHeader("Pragma", "no-cache");
      response->addHeader("Expires", "0");
      request->send(response);
    } else {
      request->send(500, "application/json", "{\"error\":\"no_provider\"}");
    }
  });

  // Runtime metadata endpoint
  server->on("/runtime_meta.json", HTTP_GET, [this](AsyncWebServerRequest* request) {
    String pageKey;
    bool selected = false;
    // Invalid selectors send 400; missing managers or unknown page keys send 404.
    // cppcheck-suppress knownConditionTrueFalse
    if (!readLivePageSelection(request, configManager, pageKey, selected))
      return;
    if (runtimeMetaJsonProvider || selected) {
      const uint32_t activeRequests = ++runtimeMetaActiveRequests;
      std::shared_ptr<const String> payload;
      if (selected) {
        String json = configManager->buildLivePageMetadataJSON(pageKey);
        if (json.length())
          payload = std::make_shared<String>(std::move(json));
      } else {
        payload = runtimeMetaJsonProvider();
      }
      if (!payload || payload->length() == 0) {
        --runtimeMetaActiveRequests;
        logRuntimeMetaResponseFailure(0, activeRequests);
        request->send(503, "application/json", "{\"error\":\"runtime_meta_unavailable\"}");
        return;
      }
      const size_t payloadLength = payload->length();
      cm::RuntimeMetaResponse* response = new (std::nothrow) cm::RuntimeMetaResponse(std::move(payload), &runtimeMetaActiveRequests);
      if (!response || !response->hasPayload()) {
        delete response;
        if (!response) {
          --runtimeMetaActiveRequests;
        }
        logRuntimeMetaResponseFailure(payloadLength, activeRequests);
        request->send(503, "application/json", "{\"error\":\"runtime_meta_unavailable\"}");
        return;
      }
      enableCORS(response);
      response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      response->addHeader("Pragma", "no-cache");
      response->addHeader("Expires", "0");
      request->send(response);
    } else {
      request->send(500, "application/json", "{\"error\":\"no_provider\"}");
    }
  });

#if !CM_ENABLE_WS_PUSH
  // Gracefully handle WebSocket requests when WS push is disabled to avoid 404 log spam
  server->on("/ws", HTTP_GET, [this](AsyncWebServerRequest* request) {
    // If the client attempts a WebSocket handshake, we deliberately respond with 426
    // so the browser treats it as an upgrade-required failure (no noisy 404 logging).
    AsyncWebServerResponse* response = request->beginResponse(426, "text/plain", "WebSocket disabled");
    response->addHeader("Connection", "close");
    response->addHeader("Sec-WebSocket-Version", "13");
    request->send(response);
  });
#endif

  setupRuntimeActionRoutes();
#endif
}

// Cppcheck rationale: Preserve the existing instance API for source compatibility.
// cppcheck-suppress functionStatic
String ConfigManagerWeb::getContentType(const String& path) {
  if (path.endsWith(".html"))
    return "text/html";
  if (path.endsWith(".css"))
    return "text/css";
  if (path.endsWith(".js"))
    return "application/javascript";
  if (path.endsWith(".json"))
    return "application/json";
  if (path.endsWith(".ico"))
    return "image/x-icon";
  return "text/plain";
}

// Cppcheck rationale: Preserve the existing instance API for source compatibility.
// cppcheck-suppress functionStatic
void ConfigManagerWeb::log(const char* format, ...) const {
  char buffer[256];
  va_list args;
  va_start(args, format);
  vsnprintf(buffer, sizeof(buffer), format, args);
  va_end(args);
  WEB_LOG("%s", buffer);
}

void ConfigManagerWeb::setSettingsPassword(const String& password) {
  settingsPassword = password;
  WEB_LOG("Settings password configured (length: %d)", password.length());
}

bool ConfigManagerWeb::isSettingsAuthRequired() const {
  return settingsPassword.length() > 0;
}

String ConfigManagerWeb::issueSettingsAuthToken() {
  // 128-bit token encoded as hex
  uint32_t r0 = esp_random();
  uint32_t r1 = esp_random();
  uint32_t r2 = esp_random();
  uint32_t r3 = esp_random();
  char buf[33];
  snprintf(buf, sizeof(buf), "%08lx%08lx%08lx%08lx", (unsigned long)r0, (unsigned long)r1, (unsigned long)r2, (unsigned long)r3);
  settingsAuthToken = String(buf);
  settingsAuthIssuedAtMs = millis();
  WEB_LOG("Settings auth token issued (ttl=%lus)", (unsigned long)(SETTINGS_AUTH_TTL_MS / 1000UL));
  return settingsAuthToken;
}

bool ConfigManagerWeb::isSettingsAuthValid(AsyncWebServerRequest* request) const {
  if (!isSettingsAuthRequired()) {
    return true;
  }

  if (settingsAuthToken.isEmpty()) {
    return false;
  }

  const uint32_t age = (uint32_t)(millis() - settingsAuthIssuedAtMs);
  if (age > SETTINGS_AUTH_TTL_MS) {
    return false;
  }

  if (!request || !request->hasHeader("X-Settings-Token")) {
    return false;
  }
  const String token = request->getHeader("X-Settings-Token")->value();
  return token == settingsAuthToken;
}
