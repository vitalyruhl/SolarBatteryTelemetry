#pragma once

// CoreSettings.h
//
// Header-only, opt-in "core settings templates" for sketches.
//
// Rationale:
// - Keep examples/sketches smaller by providing reusable baseline settings bundles.
// - Keep this strictly opt-in: nothing changes unless the sketch includes this header and calls attach().
//
// Notes:
// - Defaults are intentionally conservative (no real credentials).
// - Settings are persisted automatically by ConfigManager when a key does not exist yet.

#include <Arduino.h>

#include "ConfigManager.h"

namespace cm {

namespace CoreCategories {
inline constexpr char WiFi[] = "WiFi";
inline constexpr char System[] = "System";
inline constexpr char Buttons[] = "Buttons";
inline constexpr char IO[] = "IO";
inline constexpr char Ntp[] = "NTP";
} // namespace CoreCategories

#if CM_ENABLE_WIFI
class ConnectivityTargetSetting : public Config<String> {
public:
  ConnectivityTargetSetting()
      : Config<String>(ConfigOptions<String>{
          .key = "WiFiProbe", .name = "Connectivity check target", .category = CoreCategories::WiFi, .defaultValue = String("off"), .showInWeb = true, .sortOrder = 19}) {}
  bool fromJSON(const JsonVariant& value) override {
    if (!value.is<const char*>() || !cm::detail::isConnectivityTarget(value.as<const char*>()))
      return false;
    return Config<String>::fromJSON(value);
  }
};

class WiFiRebootTimeoutSetting : public Config<int> {
public:
  WiFiRebootTimeoutSetting()
      : Config<int>(ConfigOptions<int>{
          .key = "WiFiRb", .name = "Reboot if WiFi lost (min)", .category = CoreCategories::WiFi, .defaultValue = 1, .showInWeb = true, .sortOrder = 20}) {}
  bool fromJSON(const JsonVariant& value) override {
    if (value.is<bool>() || !value.is<int>())
      return false;
    const int minutes = value.as<int>();
    if (minutes < 0 || minutes > 9999)
      return false;
    return Config<int>::fromJSON(value);
  }
};

class WiFiPowerSaveSetting : public Config<bool> {
public:
  WiFiPowerSaveSetting()
      : Config<bool>(ConfigOptions<bool>{.key = "WiFiPowerSave", .name = "WiFi power saving", .category = CoreCategories::WiFi, .defaultValue = CM_WIFI_POWER_SAVE_DEFAULT != 0, .showInWeb = true, .sortOrder = 18}) {}
  std::function<WiFiPowerSaveDiagnostics()> diagnostics;
  void toJSON(JsonObject& obj) const override {
    Config<bool>::toJSON(obj);
#if CM_ENABLE_SETTINGS_UI
    if (!diagnostics)
      return;
    const auto snapshot = diagnostics();
    JsonObject status = obj[getKey()]["powerSave"].to<JsonObject>();
    status["requested"] = snapshot.requested;
    status["bleCoexistenceRequired"] = snapshot.bleCoexistenceRequired;
    status["reason"] = !snapshot.requested && snapshot.bleCoexistenceRequired ? "ble_coexistence" : "requested";
    status["effectiveMode"] = snapshot.effectiveMode;
    status["readError"] = snapshot.readError;
    status["applyAttempted"] = snapshot.applyAttempted;
    status["applySucceeded"] = snapshot.applySucceeded;
    status["applyError"] = snapshot.applyError;
#endif
  }
};

struct CoreWiFiSettings {
  Config<String> wifiSsid{ConfigOptions<String>{.key = "WiFiSSID", .name = "WiFi SSID", .category = CoreCategories::WiFi, .defaultValue = String(""), .showInWeb = true, .sortOrder = 1}};
  Config<String> wifiPassword{ConfigOptions<String>{.key = "WiFiPassword", .name = "WiFi Password", .category = CoreCategories::WiFi, .defaultValue = String(""), .showInWeb = true, .isPassword = true, .sortOrder = 2}};
  Config<bool> useDhcp{ConfigOptions<bool>{.key = "WiFiUseDHCP", .name = "Use DHCP", .category = CoreCategories::WiFi, .defaultValue = true, .showInWeb = true, .sortOrder = 3}};

  Config<String> staticIp{ConfigOptions<String>{.key = "WiFiStaticIP", .name = "Static IP", .category = CoreCategories::WiFi, .defaultValue = String("192.168.0.10"), .showInWeb = true, .sortOrder = 4}};
  Config<String> gateway{ConfigOptions<String>{.key = "WiFiGateway", .name = "Gateway", .category = CoreCategories::WiFi, .defaultValue = String("192.168.0.1"), .showInWeb = true, .sortOrder = 5}};
  Config<String> subnet{ConfigOptions<String>{.key = "WiFiSubnet", .name = "Subnet Mask", .category = CoreCategories::WiFi, .defaultValue = String("255.255.255.0"), .showInWeb = true, .sortOrder = 6}};
  Config<String> dnsPrimary{ConfigOptions<String>{.key = "WiFiDNS1", .name = "Primary DNS", .category = CoreCategories::WiFi, .defaultValue = String("192.168.0.1"), .showInWeb = true, .sortOrder = 7}};
  Config<String> dnsSecondary{ConfigOptions<String>{.key = "WiFiDNS2", .name = "Secondary DNS", .category = CoreCategories::WiFi, .defaultValue = String("8.8.8.8"), .showInWeb = true, .sortOrder = 8}};

  WiFiPowerSaveSetting powerSave;
  ConnectivityTargetSetting connectivityTarget;
  WiFiRebootTimeoutSetting rebootTimeoutMin;

  void attachTo(ConfigManagerClass& cfg) {
    cfg.addSetting(&wifiSsid);
    cfg.addSetting(&wifiPassword);
    cfg.addSetting(&useDhcp);
    cfg.addSetting(&staticIp);
    cfg.addSetting(&gateway);
    cfg.addSetting(&subnet);
    cfg.addSetting(&dnsPrimary);
    cfg.addSetting(&dnsSecondary);
    cfg.addSetting(&powerSave);
    cfg.addSetting(&connectivityTarget);
    cfg.addSetting(&rebootTimeoutMin);
    powerSave.setCallback([&cfg](bool enabled) { cfg.setWiFiPowerSave(enabled); });
    powerSave.diagnostics = [&cfg]() { return cfg.getWiFiManager().getPowerSaveDiagnostics(); };
    connectivityTarget.setCallback([&cfg](const String& value) { cfg.setConnectivityCheckTarget(value); });
    rebootTimeoutMin.setCallback([&cfg](int minutes) { cfg.setWiFiAutoRebootTimeout(minutes < 0 ? 0u : std::min(9999u, static_cast<uint32_t>(minutes))); });

    // Keep DHCP-dependent visibility consistent with the original demo pattern.
    staticIp.showIfFunc = [this]() { return !useDhcp.get(); };
    gateway.showIfFunc = [this]() { return !useDhcp.get(); };
    subnet.showIfFunc = [this]() { return !useDhcp.get(); };
    dnsPrimary.showIfFunc = [this]() { return !useDhcp.get(); };
    dnsSecondary.showIfFunc = [this]() { return !useDhcp.get(); };
  }
};
#endif

struct CoreSystemSettings {
  explicit CoreSystemSettings(const String& defaultVersion)
      : allowOTA(ConfigOptions<bool>{.key = "OTAEn", .name = "Allow OTA Updates", .category = CoreCategories::System, .defaultValue = true, .showInWeb = true, .sortOrder = 1}),
        otaPassword(ConfigOptions<String>{.key = "OTAPass", .name = "OTA Password", .category = CoreCategories::System, .defaultValue = String(""), .showInWeb = true, .isPassword = true, .sortOrder = 2}),
        version(ConfigOptions<String>{.key = "P_Version", .name = "Program Version", .category = CoreCategories::System, .defaultValue = defaultVersion, .showInWeb = true, .sortOrder = 3}) {
  }

  Config<bool> allowOTA;
  Config<String> otaPassword;
  Config<String> version;

  void attachTo(ConfigManagerClass& cfg) {
    cfg.addSetting(&allowOTA);
    cfg.addSetting(&otaPassword);
    cfg.addSetting(&version);
  }
};

struct CoreNtpSettings {
  Config<int> frequencySec{ConfigOptions<int>{.key = "NTPFrq", .name = "NTP Sync Interval (s)", .category = CoreCategories::Ntp, .defaultValue = 3600, .showInWeb = true, .sortOrder = 1}};
  Config<String> server1{ConfigOptions<String>{.key = "NTP1", .name = "NTP Server 1", .category = CoreCategories::Ntp, .defaultValue = String("192.168.2.250"), .showInWeb = true, .sortOrder = 2}};
  Config<String> server2{ConfigOptions<String>{.key = "NTP2", .name = "NTP Server 2", .category = CoreCategories::Ntp, .defaultValue = String("pool.ntp.org"), .showInWeb = true, .sortOrder = 3}};
  Config<String> tz{ConfigOptions<String>{.key = "NTPTZ", .name = "Time Zone (POSIX)", .category = CoreCategories::Ntp, .defaultValue = String("CET-1CEST,M3.5.0/02,M10.5.0/03"), .showInWeb = true, .sortOrder = 4}};

  void attachTo(ConfigManagerClass& cfg) {
    cfg.addSetting(&frequencySec);
    cfg.addSetting(&server1);
    cfg.addSetting(&server2);
    cfg.addSetting(&tz);
  }
};

struct CoreButtonSettings {
  // Pins are disabled by default.
  // Convention: pin < 0 means "not present" (skip pinMode/digitalRead).
  // Note: ESP32 has GPIO0. It is a boot strapping pin, so using it for buttons is possible but needs care.
  // TODO(IOManager): Later move button handling (pinMode/digitalRead/debounce) into an IOManager module.
  // API idea:
  //   - bool IOManager::checkResetToDefaultsButton(const CoreButtonSettings& cfg, std::function<void()> onPressed);
  //   - bool IOManager::checkApModeButton(const CoreButtonSettings& cfg, std::function<void()> onPressed);
  // Notes:
  //   - The callback should decide the action (e.g. show feedback, clear prefs, reboot).
  Config<int> apModePin{ConfigOptions<int>{.key = "BtnAP", .name = "AP Mode Button GPIO", .category = CoreCategories::Buttons, .defaultValue = -1, .showInWeb = true, .sortOrder = 1}};
  Config<int> resetDefaultsPin{ConfigOptions<int>{.key = "BtnRst", .name = "Reset Defaults Button GPIO", .category = CoreCategories::Buttons, .defaultValue = -1, .showInWeb = true, .sortOrder = 2}};

  // Default behavior matches the existing examples: INPUT_PULLUP + pressed == LOW.
  Config<bool> apModeActiveLow{ConfigOptions<bool>{.key = "BtnAPLow", .name = "AP Mode LOW-Active", .category = CoreCategories::Buttons, .defaultValue = true, .showInWeb = true, .sortOrder = 3}};
  Config<bool> apModeUsePullup{ConfigOptions<bool>{.key = "BtnAPPU", .name = "AP Mode Use Pull-Up", .category = CoreCategories::Buttons, .defaultValue = true, .showInWeb = true, .sortOrder = 4}};

  Config<bool> resetActiveLow{ConfigOptions<bool>{.key = "BtnRstLow", .name = "Reset LOW-Active", .category = CoreCategories::Buttons, .defaultValue = true, .showInWeb = true, .sortOrder = 5}};
  Config<bool> resetUsePullup{ConfigOptions<bool>{.key = "BtnRstPU", .name = "Reset Use Pull-Up", .category = CoreCategories::Buttons, .defaultValue = true, .showInWeb = true, .sortOrder = 6}};

  void attachTo(ConfigManagerClass& cfg) {
    cfg.addSetting(&apModePin);
    cfg.addSetting(&resetDefaultsPin);

    cfg.addSetting(&apModeActiveLow);
    cfg.addSetting(&apModeUsePullup);
    cfg.addSetting(&resetActiveLow);
    cfg.addSetting(&resetUsePullup);
  }
};

class CoreSettings {
public:
  static CoreSettings& instance() {
    static CoreSettings inst;
    return inst;
  }

  // Attach all core settings bundles.
  void attach(ConfigManagerClass& cfg) {
#if CM_ENABLE_WIFI
    attachWiFi(cfg);
#endif
    attachSystem(cfg);
    attachButtons(cfg);
  }

#if CM_ENABLE_WIFI
  void attachWiFi(ConfigManagerClass& cfg,
                  const char* pageName = CoreCategories::WiFi,
                  const char* groupPretty = "WiFi Settings",
                  int order = 10) {
    if (wifiAttached)
      return;
    registerCoreLayout(cfg, pageName, CoreCategories::WiFi, groupPretty, "WiFi Settings", order);
    wifi.attachTo(cfg);
    wifiAttached = true;
  }
#endif

  void attachSystem(ConfigManagerClass& cfg,
                    const char* pageName = CoreCategories::System,
                    const char* groupPretty = "System Settings",
                    int order = 20) {
    if (systemAttached)
      return;
    registerCoreLayout(cfg, pageName, CoreCategories::System, groupPretty, "System Settings", order);
    system.attachTo(cfg);
    systemAttached = true;
  }

  void attachButtons(ConfigManagerClass& cfg) {
    if (buttonsAttached)
      return;
    buttons.attachTo(cfg);
    buttonsAttached = true;
  }

  // Optional bundle: NTP settings.
  // Intentionally not part of attach() to keep the core bundles minimal.
  void attachNtp(ConfigManagerClass& cfg,
                 const char* pageName = CoreCategories::Ntp,
                 const char* groupPretty = "NTP Settings",
                 int order = 30) {
    if (ntpAttached)
      return;
    registerCoreLayout(cfg, pageName, CoreCategories::Ntp, groupPretty, "NTP Settings", order);
    ntp.attachTo(cfg);
    ntpAttached = true;
  }

#if CM_ENABLE_WIFI
  CoreWiFiSettings wifi;
#endif
  CoreButtonSettings buttons;
  CoreSystemSettings system{String(CONFIGMANAGER_VERSION)};
  CoreNtpSettings ntp;

private:
  CoreSettings() = default;

#if CM_ENABLE_WIFI
  bool wifiAttached = false;
#endif
  bool systemAttached = false;
  bool buttonsAttached = false;
  bool ntpAttached = false;

  static void registerCoreLayout(ConfigManagerClass& cfg,
                                 const char* pageName,
                                 const char* defaultPage,
                                 const char* groupPretty,
                                 const char* defaultGroupPretty,
                                 int order) {
    const char* resolvedPage = (pageName && pageName[0]) ? pageName : defaultPage;
    const char* resolvedGroup = (groupPretty && groupPretty[0]) ? groupPretty : defaultGroupPretty;
    cfg.setCategoryLayoutOverride(defaultPage, resolvedPage, resolvedPage, resolvedGroup, order);
    cfg.addSettingsPage(resolvedPage, order);
    cfg.addSettingsGroup(resolvedPage, resolvedPage, resolvedGroup, order);
  }

  // Intentionally no dynamic allocation here.
};

} // namespace cm
